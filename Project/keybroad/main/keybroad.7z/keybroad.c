#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "driver/gpio.h"


#define key_r1 19
#define key_r2 13
#define key_r3 0
#define key_r4 1

#define key_c1 2
#define key_c2 3
#define key_c3 10
#define key_c4 6


#define motor1 7
#define motor2 18
#define motor3 12
#define motor4 8

TaskHandle_t motor_1;
TaskHandle_t motor_2;
TaskHandle_t motor_3;
void key(void *pvParam );
void key_r(int *tem,int *point ,gpio_num_t gpio_num);



//int key[12]={1,2,3,4,9,10,11,12,13,14,15,16,17,18};
int singn[18];
   

void app_main(void)
{
//电机gpio设置
gpio_config_t motor_conf;

   motor_conf.mode = GPIO_MODE_OUTPUT;
   motor_conf.pin_bit_mask = (1 << motor1) | (1 << motor2) | (1 << motor3) | (1 << motor4);
   esp_err_t r = gpio_config(&motor_conf);


//电机四根信号线全部输出高电平
   gpio_set_level(motor1, 1);
   gpio_set_level(motor2, 1);
   gpio_set_level(motor3, 1);
   gpio_set_level(motor4, 1);


   //int singn[18];
   singn[6]=1;
   singn[7]=2;
   singn[8]=3;
   singn[9]=4;


   singn[10]=9;
   singn[11]=10;
   singn[12]=11;
   singn[13]=12;


   singn[14]=13;
   singn[15]=14;
   singn[16]=15;
   singn[17]=16;
   
    void motor_left(void *pvParam );
    void motor_right(void *pvParam );
    void motor_over(void *pvParam );



    



   
   




   //TaskHandle_t motor_1;
    xTaskCreate(key,"keybroad",10000,(void*) singn,1, NULL);
    xTaskCreate(motor_left,"motorl",10000,NULL,1, &motor_1);
    xTaskCreate(motor_right,"motorr",10000,NULL,1, &motor_2);
    xTaskCreate(motor_over,"motorro",10000,NULL,1, &motor_3);
    vTaskSuspend(motor_1);
    vTaskSuspend(motor_2);
     vTaskSuspend(motor_3);
    
    //vTaskResume(motor_1);
  
}






void motor_left( void *pvParam){
  while(1){
   gpio_set_level(motor1, 0);
  vTaskDelay(10 / portTICK_PERIOD_MS);
   gpio_set_level(motor1, 1);
   gpio_set_level(motor2, 0); 
   vTaskDelay(10 / portTICK_PERIOD_MS);
   gpio_set_level(motor2, 1);
   gpio_set_level(motor3, 0); 
   vTaskDelay(10 / portTICK_PERIOD_MS);
   gpio_set_level(motor3, 1);
   gpio_set_level(motor4, 0); 
   vTaskDelay(10 / portTICK_PERIOD_MS);
   gpio_set_level(motor4, 1);
   vTaskDelay(10 / portTICK_PERIOD_MS);
  }
}

   


void motor_right(void *pvParam ){
   while(1){
   gpio_set_level(motor4, 0);
  vTaskDelay(10 / portTICK_PERIOD_MS);
   gpio_set_level(motor4, 1);
   gpio_set_level(motor3, 0); 
   vTaskDelay(10 / portTICK_PERIOD_MS);
   gpio_set_level(motor3, 1);
   gpio_set_level(motor2, 0); 
   vTaskDelay(10 / portTICK_PERIOD_MS);
   gpio_set_level(motor2, 1);
   gpio_set_level(motor1, 0); 
   vTaskDelay(10 / portTICK_PERIOD_MS);
   gpio_set_level(motor1, 1);
   vTaskDelay(10 / portTICK_PERIOD_MS);
   }
}



void motor_over(void *pvParam  ){
  while(1){
   gpio_set_level(motor1,1);
   gpio_set_level(motor2,2);
   gpio_set_level(motor3,1);
   gpio_set_level(motor4,1);   
  vTaskDelay(10 / portTICK_PERIOD_MS);
}


}


//键盘对行扫描函数
void key_r(int *tem,int *point ,gpio_num_t gpio_num){
   gpio_config_t led_conf;
    memset(&led_conf,0,sizeof(led_conf));
   led_conf.mode = GPIO_MODE_OUTPUT;
   led_conf.pin_bit_mask = (1<<key_r1)|(1<<key_r2)|(1<<key_r3)|(1<<key_r4);
   led_conf.pull_down_en = 0; 
   esp_err_t r = gpio_config(&led_conf);
   

   gpio_config_t led_conf1;
   led_conf1.mode = GPIO_MODE_INPUT;
   led_conf1.pin_bit_mask = (1<<key_c1)|(1<<key_c2)|(1<<key_c3)|(1<<key_c4);
   led_conf1.pull_down_en = 1;
   esp_err_t m = gpio_config(&led_conf1);
  



   gpio_set_level(gpio_num, 1);
    *(tem+4)=gpio_get_level(key_c1);
    if(*(tem+4)==1)
    {
      printf("%d\n",*point);
    
    }
    *(tem+4)=gpio_get_level(key_c2);
     if(*(tem+4)==1)
    {printf("%d\n",*(point+1));
    
    }  
    *(tem+4)=gpio_get_level(key_c3);
     if(*(tem+4)==1)
    {printf("%d\n",*(point+2));
    
    } 
     *(tem+4)=gpio_get_level(key_c4);
     if(*(tem+4)==1)
    {printf("%d\n",*(point+3));
      
    
    }
}










//键盘函数
void key(void *pvParam ){


gpio_config_t led_conf;
  
    memset(&led_conf,0,sizeof(led_conf));

   led_conf.mode = GPIO_MODE_INPUT;
   led_conf.pin_bit_mask = (1<<key_r1)|(1<<key_r2)|(1<<key_r3)|(1<<key_r4);
   led_conf.pull_down_en = 1; 


gpio_config_t led_conf1;
   
   led_conf1.mode = GPIO_MODE_OUTPUT;
   led_conf1.pin_bit_mask = (1<<key_c1)|(1<<key_c2)|(1<<key_c3)|(1<<key_c4);


   int *pArrayAddr;
    pArrayAddr=(int *)pvParam;
   
 while(1){
   
  

  //gpio_config_t led_conf;
  
   // memset(&led_conf,0,sizeof(led_conf));

   //led_conf.mode = GPIO_MODE_INPUT;
   //led_conf.pin_bit_mask = (1<<key_r1)|(1<<key_r2)|(1<<key_r3)|(1<<key_r4);
   //led_conf.pull_down_en = 1; 
   esp_err_t r = gpio_config(&led_conf);
  



//gpio_config_t led_conf1;
   

   //led_conf1.mode = GPIO_MODE_OUTPUT;
   //led_conf1.pin_bit_mask = (1<<key_c1)|(1<<key_c2)|(1<<key_c3)|(1<<key_c4);
   
   esp_err_t m = gpio_config(&led_conf1);
 



  
     gpio_set_level(key_c1, 1);
     gpio_set_level(key_c2, 1);
     gpio_set_level(key_c3, 1);
     gpio_set_level(key_c4, 1);
    
   
    *pArrayAddr=gpio_get_level(key_r1);
    *(pArrayAddr+1)=gpio_get_level(key_r2);
    *(pArrayAddr+2)=gpio_get_level(key_r3);
    *(pArrayAddr+3)=gpio_get_level(key_r4);

    
    

    //扫描第一行
    if(*pArrayAddr==1)
    {
      //调用函数扫描第一行
      key_r(pArrayAddr,pArrayAddr+6 ,key_r1);




      
   /*gpio_config_t led_conf;
    memset(&led_conf,0,sizeof(led_conf));
   led_conf.mode = GPIO_MODE_OUTPUT;
   led_conf.pin_bit_mask = (1<<key_r1)|(1<<key_r2)|(1<<key_r3)|(1<<key_r4);
   led_conf.pull_down_en = 0; 
   esp_err_t r = gpio_config(&led_conf);
   



   gpio_config_t led_conf1;
   led_conf1.mode = GPIO_MODE_INPUT;
   led_conf1.pin_bit_mask = (1<<key_c1)|(1<<key_c2)|(1<<key_c3)|(1<<key_c4);
   led_conf1.pull_down_en = 1;
   esp_err_t m = gpio_config(&led_conf1);
  



   gpio_set_level(key_r1, 1);
    *(pArrayAddr+4)=gpio_get_level(key_c1);
    if(*(pArrayAddr+4)==1)
    {printf("1\n");
    //continue;
    }
    *(pArrayAddr+4)=gpio_get_level(key_c2);
     if(*(pArrayAddr+4)==1)
    {printf("2\n");
    //continue;
    }  
    *(pArrayAddr+4)=gpio_get_level(key_c3);
     if(*(pArrayAddr+4)==1)
    {printf("3\n");
    //continue;
    } 
     *(pArrayAddr+4)=gpio_get_level(key_c4);
     if(*(pArrayAddr+4)==1)
    {printf("4\n");
      *(pArrayAddr+5)=4;
    //continue;
    }*/

    }
    
    
    
    //扫描第二行
    if(*(pArrayAddr+1)==1)
    {


   gpio_config_t led_conf;
    memset(&led_conf,0,sizeof(led_conf));
   led_conf.mode = GPIO_MODE_OUTPUT;
   led_conf.pin_bit_mask = (1<<key_r1)|(1<<key_r2)|(1<<key_r3)|(1<<key_r4);
   led_conf.pull_down_en = 0; 
   esp_err_t r = gpio_config(&led_conf);
  

   gpio_config_t led_conf1;
   led_conf1.mode = GPIO_MODE_INPUT;
   led_conf1.pin_bit_mask = (1<<key_c1)|(1<<key_c2)|(1<<key_c3)|(1<<key_c4);
   led_conf1.pull_down_en = 1;
   esp_err_t m = gpio_config(&led_conf1);
  

   gpio_set_level(key_r2, 1);
    *(pArrayAddr+4)=gpio_get_level(key_c1);
    if(*(pArrayAddr+4)==1)
    {printf("5\n");
     // u=5;
      //t1:
     // motor_left( );
      //goto t4;
    //continue;
    *(pArrayAddr+5)=5;
    }
    *(pArrayAddr+4)=gpio_get_level(key_c2);
     if(*(pArrayAddr+4)==1)
    {printf("6\n");
      //u=6;
      //t2:
         //motor_right( );
         //goto t4;
    //continue;
    *(pArrayAddr+5)=6;
    }  
    *(pArrayAddr+4)=gpio_get_level(key_c3);
     if(*(pArrayAddr+4)==1)
    {printf("7\n");
      //u=7;
      //t3:
        //motor_over( );
        //goto t4;
    //continue;
    *(pArrayAddr+5)=7;
    } 
     *(pArrayAddr+4)=gpio_get_level(key_c4);
     if(*(pArrayAddr+4)==1)
    {printf("8\n");
    //continue;
    }

    }
    


    //扫描第三行
    if(*(pArrayAddr+2)==1)
    {
   
   key_r(pArrayAddr,pArrayAddr+10 ,key_r3);
    /*gpio_config_t led_conf;
    memset(&led_conf,0,sizeof(led_conf));
   led_conf.mode = GPIO_MODE_OUTPUT;
   led_conf.pin_bit_mask = (1<<key_r1)|(1<<key_r2)|(1<<key_r3)|(1<<key_r4);
   led_conf.pull_down_en = 0; 
   esp_err_t r = gpio_config(&led_conf);
  
   gpio_config_t led_conf1;
   led_conf1.mode = GPIO_MODE_INPUT;
   led_conf1.pin_bit_mask = (1<<key_c1)|(1<<key_c2)|(1<<key_c3)|(1<<key_c4);
   led_conf1.pull_down_en = 1;
   esp_err_t m = gpio_config(&led_conf1);
  


   gpio_set_level(key_r3, 1);
    *(pArrayAddr+4)=gpio_get_level(key_c1);
    if(*(pArrayAddr+4)==1)
    {printf("9\n");
    //continue;
    }
    *(pArrayAddr+4)=gpio_get_level(key_c2);
     if(*(pArrayAddr+4)==1)
    {printf("10\n");
    //continue;
    }  
    *(pArrayAddr+4)=gpio_get_level(key_c3);
     if(*(pArrayAddr+4)==1)
    {printf("11\n");
    //continue;
    } 
     *(pArrayAddr+4)=gpio_get_level(key_c4);
     if(*(pArrayAddr+4)==1)
    {printf("12\n");
    //continue;
    }*/

    }
    




   //扫描第四行
    if(*(pArrayAddr+3)==1)
    {
   
    key_r(pArrayAddr,pArrayAddr+14 ,key_r4);
   /* gpio_config_t led_conf;
    memset(&led_conf,0,sizeof(led_conf));
   led_conf.mode = GPIO_MODE_OUTPUT;
   led_conf.pin_bit_mask = (1<<key_r1)|(1<<key_r2)|(1<<key_r3)|(1<<key_r4);
   led_conf.pull_down_en = 0; 
   esp_err_t r = gpio_config(&led_conf);
  
   gpio_config_t led_conf1;
   led_conf1.mode = GPIO_MODE_INPUT;
   led_conf1.pin_bit_mask = (1<<key_c1)|(1<<key_c2)|(1<<key_c3)|(1<<key_c4);
   led_conf1.pull_down_en = 1;
   esp_err_t m = gpio_config(&led_conf1);
 


   gpio_set_level(key_r4, 1);
    *(pArrayAddr+4)=gpio_get_level(key_c1);
    if(*(pArrayAddr+4)==1)
    {printf("13\n");
    //continue;
   }
    *(pArrayAddr+4)=gpio_get_level(key_c2);
     if(*(pArrayAddr+4)==1)
    {printf("   14\n");
    //continue;
   }  
    *(pArrayAddr+4)=gpio_get_level(key_c3);
     if(*(pArrayAddr+4)==1)
    {printf("15\n");
    //continue;
   } 
     *(pArrayAddr+4)=gpio_get_level(key_c4);
     if(*(pArrayAddr+4)==1)
    {printf("16\n");
    //continue;
   }*/

    }
    
    
    if(*(pArrayAddr+5)==5)
    {
      vTaskSuspend(motor_3);
      vTaskSuspend(motor_2);
      vTaskResume(motor_1);

   
   }

    if(*(pArrayAddr+5)==6)
    {
      vTaskSuspend(motor_3);
      vTaskSuspend(motor_1);
      vTaskResume(motor_2);
    }

    if(*(pArrayAddr+5)==7)
    {
      vTaskSuspend(motor_1);
      vTaskSuspend(motor_2);
      vTaskResume(motor_3);
    }
      vTaskDelay(50 / portTICK_PERIOD_MS); 
   }

}