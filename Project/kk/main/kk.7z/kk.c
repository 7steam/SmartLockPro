#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "driver/gpio.h"
#include <pthread.h>


void* pp(){
   for(int i=0;i<100;i++){
    printf("%d\n",i);}
    return NULL;
}


/*#define gg1 9
#define gg2 4*/


/*void yu(gpio_num_t r){
int k=gpio_get_level(r);
printf("11111\n");
printf("%d\n",k);
printf("11111\n");
}*/


void app_main(void)
{


pthread_t th1;
pthread_t th2;
pthread_create(&th1,NULL,pp,NULL);
pthread_create(&th2,NULL,pp,NULL);
pthread_join(th1,NULL);
pthread_join(th2,NULL);    




}
